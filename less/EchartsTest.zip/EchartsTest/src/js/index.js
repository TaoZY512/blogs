$(function() {
     let tool = new Tool();
     tool.basic();
     tool.test();
     tool.test1();
});
