let loadingHtml = (parent, response) => {
    let datas = response["goods"];
    let htmlStr = "";
    datas.forEach(data => {
        htmlStr += `
        <li><a href="#">
        <section class="one">
         <img src="${data.img}" alt="">
        </section>
        <section>
            <p>${data.model}</p>
            <div class="null"></div>
            <p>${data.price}</p>
        </section>
        
    </a></li>
        `;
    });
    parent.html(htmlStr);
};
let isShow = el => {
    let winH = $(window).height(),
        scrollH = $(window).scrollTop(),
        top = el.offset().top;
    console.log(scrollH + winH);
    console.log(top);
    if (top < scrollH + winH) {
        el.addClass("running");
    }
};

// $.addEvent(window, "scroll", function () {
//     offset = document.body.scrollTop || document.documentElement.scrollTop;
//     for(var i = 0, len = items.length; i < len; i++) {
//         if(kHeight + offset > offsetTops[i]) {
//             items[i].classList.add("running");
//         }
//     }
// });