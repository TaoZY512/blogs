$(function () {
  //图片轮播
  setInterval(function () {
    $(".lun-bottom img").toggleClass("show");
  }, 3000);

  //1.获取数据
  $.ajax({
    url: "../json/index.json",
    type: "GET",
    dataType: "json",
    success: response => {
      // 2. 加载数据
      loadingHtml($(".commodity-list"), response);
    }
  });
  let result = $(".upload")[1];
  console.log(result);
  isShow($(".upload"));
  isShow($(".upload-p"));
  isShow($(".load"));
  isShow($(".activity"));
});